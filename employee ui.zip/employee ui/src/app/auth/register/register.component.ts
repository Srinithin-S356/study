import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  imports: [CommonModule, FormsModule]
})
export class RegisterComponent {
  form = {
    username: '',
    email: '',
    password: '',
    dept: '',
    mobileNo: '',
    role: 'EMPLOYEE' // Default role
  };
  message = '';

  constructor(private auth: AuthService, private router: Router) { }

  register(registerForm: NgForm) {
    if (registerForm.invalid) {
      this.message = 'Please fill in all required fields.';
      return;
    }

    this.auth.register(this.form).subscribe({
      next: (res) => {
        this.message = 'Registration successful!';
        this.form = { username: '', email: '', password: '', dept: '', mobileNo: '', role: 'EMPLOYEE' }; // Reset form
        registerForm.resetForm();
        // Automatically navigate to the login page after successful registration
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.message = 'Registration failed: ' + (' user already exists.');
      }
    });
  }
}