
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

interface Feedback {
  fromemployeeID: number;
  employeeID: number;
  feedbacktype: string;
  comments: string;
}

interface MilestoneUpdateDTO {
  milestoneID: number;
  progressStatus: string;
  goalID: number;
  employeeID: number;
}

interface EmployeeProfile {
  employeeID: number;
  username: string;
  email: string;
  dept: string;
  mobileNo: string;
  roles: any[];
}

interface ApiResponse { // Define an interface for your expected JSON response
  message: string;
}

@Injectable({ providedIn: 'root' })
export class EmployeeService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);
  private baseUrl = 'http://localhost:9092/employee';

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      Authorization: `Bearer ${this.auth.getToken() || ''}`
    });
  }

  getGoals(employeeId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getAllGoal/${employeeId}`, {
      headers: this.getHeaders()
    });
  }

  getMilestones(goalId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getAllMilestones/${goalId}`, {
      headers: this.getHeaders()
    });
  }

  giveFeedback(feedback: Feedback): Observable<any> {
    return this.http.post(`${this.baseUrl}/giveFeedback`, feedback, {
      headers: this.getHeaders()
    });
  }

  updateMilestone(milestone: any, goalId: number, employeeId: number): Observable<ApiResponse> {
    const milestoneUpdateDTO: MilestoneUpdateDTO = {
      milestoneID: milestone.milestoneID,
      progressStatus: milestone.progressStatus,
      goalID: goalId,
      employeeID: employeeId
    };
    return this.http.post<ApiResponse>(`${this.baseUrl}/updateMilestone`, milestoneUpdateDTO, {
      headers: this.getHeaders()
    });
  }

  getEmployeeProfile(employeeId: number): Observable<EmployeeProfile> {
    return this.http.get<EmployeeProfile>(`${this.baseUrl}/profile/${employeeId}`, { headers: this.auth.getAuthHeaders() });
  }
}
