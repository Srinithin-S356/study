import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../../services/employee.service';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { HttpErrorResponse } from '@angular/common/http';

interface Milestone {
  milestoneID: number;
  milestoneDesc: string;
  targetDate: string;
  progressStatus: string;
  goalID: number; // Assuming your milestone object has goalID
  employeeID: number; // Assuming your milestone object has employeeID
  // ... other properties
}

interface EmployeeProfile {
  employeeID: number;
  username: string;
  email: string;
  dept: string;
  mobileNo: string;
  roles: any[];
}

interface PasswordForm {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
}

@Component({
  standalone: true,
  selector: 'app-employee-dashboard',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  imports: [CommonModule, FormsModule]
})
export class EmployeeComponent implements OnInit {
  employeeId!: number;
  goals: any[] = [];
  milestones: Milestone[] = []; // Ensure milestones are typed
  selectedGoalId!: number;
  feedback = {
    fromemployeeID: 0,
    employeeID: 0,
    feedbacktype: '',
    comments: ''
  };

  employeeProfile: EmployeeProfile | null = null;
  profileError: string = '';

  passwordForm: PasswordForm = {
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  };
  passwordUpdateMessage: string = '';
  passwordUpdateError: string = '';

  constructor(private empService: EmployeeService, private auth: AuthService) {}

  ngOnInit(): void {
    const token = this.auth.getToken();
    const payload = JSON.parse(atob(token!.split('.')[1]));
    this.employeeId = parseInt(payload.employeeID);
    this.feedback.fromemployeeID = this.employeeId;

    this.empService.getGoals(this.employeeId).subscribe(data => {
      this.goals = data;
    });
  }

  showSection(sectionId: string) {
    const sections = ['goalsSection', 'feedbackSection', 'profileSection', 'updatePasswordSection', 'viewGoalsSection'];
    sections.forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        element.classList.add('d-none');
      }
      const link = document.getElementById(id.replace('Section', 'Link'));
      if (link) {
        link.classList.remove('active');
      }
    });

    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
      selectedSection.classList.remove('d-none');
    }
    const selectedLink = document.getElementById(sectionId.replace('Section', 'Link'));
    if (selectedLink) {
      selectedLink.classList.add('active');
    }

    if (sectionId === 'profileSection' && !this.employeeProfile) {
      this.loadEmployeeProfile();
    }
    else if (sectionId === 'updatePasswordSection') {
      this.passwordForm = { oldPassword: '', newPassword: '', confirmPassword: '' };
      this.passwordUpdateMessage = '';
      this.passwordUpdateError = '';
    }
  }

  loadEmployeeProfile() {
    this.empService.getEmployeeProfile(this.employeeId).subscribe({
      next: (profile) => {
        this.employeeProfile = profile;
        this.profileError = '';
      },
      error: (error: HttpErrorResponse) => {
        this.employeeProfile = null;
        this.profileError = 'Error loading profile.';
        console.error('Error loading employee profile:', error);
      }
    });
  }

  
viewMilestones(goalId: number, event: Event) {
   event.preventDefault();
   this.selectedGoalId = goalId;
   this.empService.getMilestones(goalId).subscribe(data => {
   this.milestones = data;
   });
   }
  

   updateMilestoneStatus(milestone: any) {
    this.empService.updateMilestone(milestone, this.selectedGoalId, this.employeeId).subscribe({
      next: (response) => {
        alert(`Milestone ${milestone.milestoneDesc}updated to ${milestone.progressStatus}`);
        // Optionally refresh the milestones list to reflect the change immediately
        this.empService.getMilestones(this.selectedGoalId).subscribe(updatedMilestones => {
          this.milestones = updatedMilestones;
        });
        // Refresh the goals list to see the updated goal status
        this.empService.getGoals(this.employeeId).subscribe(updatedGoals => {
          this.goals = updatedGoals;
        });
      },
      error: (error) => {
        console.error('Error updating milestone:', error);
        // Handle error here, e.g., display an error message to the user
        alert('Failed to update milestone.');
      }
    });
  }

  submitFeedback() {
    this.empService.giveFeedback(this.feedback).subscribe(() => {
      alert('Feedback submitted!');
      this.feedback = { fromemployeeID: this.employeeId, employeeID: 0, feedbacktype: '', comments: '' };
    });
  }

  updatePassword() {
    this.passwordUpdateMessage = '';
    this.passwordUpdateError = '';
    if (this.passwordForm.newPassword !== this.passwordForm.confirmPassword) {
      this.passwordUpdateError = 'New password and confirm password do not match.';
      return;
    }

    this.auth
      .updatePassword(this.passwordForm.oldPassword, this.passwordForm.newPassword)
      .subscribe({
        next: (response: any) => {
          this.passwordUpdateMessage = response.message;
          this.passwordForm = {
            oldPassword: '',
            newPassword: '',
            confirmPassword: '',
          };
          this.showSection('viewGoalsSection'); // Redirect or show success message
        },
        error: (error: HttpErrorResponse) => {
          if (error.error && error.error.error) {
            this.passwordUpdateError = error.error.error;
          } else if (error.message) {
            this.passwordUpdateError = error.message;
          } else {
            this.passwordUpdateError = 'Failed to update password.';
          }
        },
      });
  }

  logout() {
    this.auth.logout();
  }
}