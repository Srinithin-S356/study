import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { authGuard } from './auth.guard';
import { AuthService } from '../services/auth.service';
import { of } from 'rxjs';

describe('AuthGuard', () => {
  let guard: authGuard;
  let authServiceMock: any;
  let routerMock: any;

  beforeEach(() => {
    authServiceMock = {
      getToken: jasmine.createSpy(),
    };

    routerMock = {
      navigate: jasmine.createSpy()
    };

    TestBed.configureTestingModule({
      providers: [
        authGuard,
        { provide: AuthService, useValue: authServiceMock },
        { provide: Router, useValue: routerMock }
      ]
    });

    guard = TestBed.inject(authGuard);
  });

  it('should allow navigation if user is authenticated with correct role', () => {
    const token = btoa(JSON.stringify({})) + '.' + btoa(JSON.stringify({
      roles: ['ADMIN']
    })) + '.testsig';

    authServiceMock.getToken.and.returnValue(token);

    const route: any = { data: { role: 'ADMIN' } };
    const state: any = {};

    expect(guard.canActivate(route, state)).toBeTrue();
  });

  it('should block navigation if no token is present', () => {
    authServiceMock.getToken.and.returnValue(null);

    const route: any = { data: { role: 'ADMIN' } };
    const state: any = {};

    expect(guard.canActivate(route, state)).toBeFalse();
    expect(routerMock.navigate).toHaveBeenCalledWith(['/login']);
  });
});
