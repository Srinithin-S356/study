
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * A role-based route guard factory
 * @param expectedRole The role required to activate the route
 * @returns CanActivateFn for the route
 */
export const roleGuard = (expectedRole: string): CanActivateFn => {
  return () => {
    const auth = inject(AuthService);
    const router = inject(Router);
    const token = auth.getToken();

    if (!token) {
      router.navigate(['/login']);
      return false;
    }

    const payload = JSON.parse(atob(token.split('.')[1]));
    const roles = payload.roles;

    if (!roles.includes(expectedRole)) {
      router.navigate(['/login']);
      return false;
    }

    return true;
  };
};
