package com.cts.ems.exception;

public class InvalidEmployeeRoleException extends RuntimeException{

	public InvalidEmployeeRoleException(String message) {
		super(message);
	}
}
