package com.cts.ems.enums;

public enum Role {

	ADMIN,
	MANAGER,
	EMPLOYEE
}
